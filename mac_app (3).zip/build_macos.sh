#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt scikit-learn joblib pyinstaller
pyinstaller --noconfirm --windowed --name LeafClimateProxy --paths . leaf_climate_app.py
mkdir -p "dist/LeafClimateProxy.app/Contents/Resources/models_v2"
cp ../Codebubby/models_v2/*.joblib "dist/LeafClimateProxy.app/Contents/Resources/models_v2/"
cp ../*.joblib "dist/LeafClimateProxy.app/Contents/Resources/"
printf '\nBuilt dist/LeafClimateProxy.app\n'
