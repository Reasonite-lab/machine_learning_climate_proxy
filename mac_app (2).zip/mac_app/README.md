# Leaf Climate Proxy — macOS App

This folder wraps every climate-output `.joblib` artifact in the repository as a local macOS desktop app.

## Build on macOS

```bash
cd mac_app
bash build_macos.sh
open dist/LeafClimateProxy.app
```

The app accepts the 31 leaf physiognomic features used by the project and returns:

- `MAT`, `WMMT`, `CMMT`, `GROWSEAS`
- `RH`, `SH`, `ENTHAL`

Each variable has a model selector. The app discovers both the seven two-stage models in `Codebubby/models_v2` and the root-level AdaBoost, CatBoost, and Stacking models. The first four variables are predicted from the 31 traits. For RH/SH/ENTHAL, the app automatically appends the four predicted temperature values when the selected model expects 35 features.

Input values must follow the training workbook definition (typically percentages or counts for a leaf assemblage). The app does not silently normalize or impute values.

## Model provenance

Models are loaded from `../Codebubby/models_v2`. The app is an inference shell around the project's existing trained artifacts; it does not retrain models. Results should be interpreted within the project's documented spatial-validation limits.
