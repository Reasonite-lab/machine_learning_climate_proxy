#!/usr/bin/env python3
"""Leaf Climate Proxy macOS desktop app.

Uses the trained models shipped in Codebubby/models_v2. Input is a single
leaf assemblage represented by the 31 CLAMP physiognomic percentages/counts.
Stage 1 predicts MAT/WMMT/CMMT/GROWSEAS; those predictions are appended to
traits for the Stage 2 RH/SH/ENTHAL models when the bundled model expects 35
features.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

FEATURES = [
    'Lobed', 'No Teeth', 'Teeth Regul', 'Teeth Close', 'Teeth Round',
    'Teeth Acute', 'Teeth Compo', 'Nanophyl', 'Leptophyl', 'Leptophyl 2',
    'Microphyl 1', 'Microphyl 2', 'Microphyl 3', 'Mesophyl 1', 'Mesophyl 2',
    'Mesophyl 3', 'Apex Emargi', 'Apex Round', 'Apex Acute', 'Apex Attenu',
    'Base Cordat', 'Base Round', 'Base Acute', 'L:W <1:1', 'L:W 1-2:1',
    'L:W 2-3:1', 'L:W 3-4:1', 'L:W >4:1', 'Obovate', 'Elliptic', 'Ovate'
]
TEMP_TARGETS = ['MAT', 'WMMT', 'CMMT', 'GROWSEAS']
MOIST_TARGETS = ['RH', 'SH', 'ENTHAL']
UNITS = {'MAT': '°C', 'WMMT': '°C', 'CMMT': '°C', 'GROWSEAS': 'months', 'RH': '%', 'SH': 'g/kg', 'ENTHAL': 'kJ/kg'}


def locate_model_dirs(extra: Path | None = None) -> list[Path]:
    here = Path(__file__).resolve()
    candidates = [here.parent, here.parent.parent, here.parent.parent / 'Codebubby', here.parent.parent / 'Codebubby' / 'models_v2', here.parent.parent / 'models_v2']
    if getattr(sys, '_MEIPASS', None):
        candidates.insert(0, Path(sys._MEIPASS))
    # In a macOS .app bundle, PyInstaller's executable is under Contents/MacOS.
    resources = Path(sys.executable).resolve().parents[1] / 'Resources'
    candidates.insert(0, resources / 'models_v2')
    candidates.insert(0, resources)
    if extra:
        candidates.insert(0, extra)
        candidates.insert(0, extra / 'models_v2')
        candidates.insert(0, extra / 'Codebubby' / 'models_v2')
    # Also support launching the script from a copied mac_app folder. Search
    # nearby parents for the two known model locations without scanning the
    # whole disk.
    for parent in [here.parent, *here.parents[:4]]:
        candidates.extend([parent / 'models_v2', parent / 'Codebubby' / 'models_v2'])
    unique = []
    seen = set()
    for path in candidates:
        path = path.resolve()
        if path.exists() and path.is_dir() and path not in seen:
            unique.append(path); seen.add(path)
    return unique


def load_models(extra_dir: Path | None = None):
    try:
        import joblib
    except ImportError as exc:
        raise RuntimeError('缺少 Python 依赖 joblib。请先运行 build_macos.sh 或 pip install -r requirements.txt。') from exc
    models = {}
    directories = locate_model_dirs(extra_dir)
    for directory in directories:
        for path in directory.glob('*.joblib'):
            stem = path.stem
            target = next((t for t in TEMP_TARGETS + MOIST_TARGETS if stem.endswith('_' + t) or stem.startswith(t + '_')), None)
            if target is None:
                continue
            label = stem.removesuffix('_' + target)
            if stem.startswith(target + '_'):
                label = stem[len(target) + 1:]
            models.setdefault(target, {})[label] = joblib.load(path)
    missing = [t for t in TEMP_TARGETS + MOIST_TARGETS if t not in models]
    if missing:
        searched = '\n'.join(str(p) for p in directories) or '没有找到可搜索的目录'
        raise RuntimeError('找不到这些气候变量的模型：' + ', '.join(missing) + '\n\n已搜索：\n' + searched + '\n\n请点击“选择模型目录”，选择包含 .joblib 文件的文件夹。')
    return models, directories


def predict(models, values, selections):
    import numpy as np
    x = np.asarray([[values[name] for name in FEATURES]], dtype=float)
    out = {}
    for target in TEMP_TARGETS:
        out[target] = float(np.asarray(models[target][selections[target]].predict(x)).ravel()[0])
    augmented = np.column_stack([x, [[out[t] for t in TEMP_TARGETS]]])
    for target in MOIST_TARGETS:
        model = models[target][selections[target]]
        n = getattr(model, 'n_features_in_', augmented.shape[1])
        data = augmented if n == augmented.shape[1] else x
        if n not in (x.shape[1], augmented.shape[1]):
            raise RuntimeError(f'{target} 模型需要 {n} 个特征，当前输入为 31 或 35 个，模型与仓库版本不匹配。')
        out[target] = float(np.asarray(model.predict(data)).ravel()[0])
    return out


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Leaf Climate Proxy')
        self.geometry('980x760')
        self.minsize(820, 620)
        self.vars = {f: tk.StringVar(value='0') for f in FEATURES}
        self.result_vars = {t: tk.StringVar(value='—') for t in TEMP_TARGETS + MOIST_TARGETS}
        self.model_vars = {t: tk.StringVar(value='') for t in TEMP_TARGETS + MOIST_TARGETS}
        self._build_ui()
        self.models = None
        self.model_dir = None
        self.after(100, self._load)

    def _build_ui(self):
        style = ttk.Style(self)
        try: style.theme_use('aqua')
        except tk.TclError: pass
        header = ttk.Frame(self, padding=(24, 18)); header.pack(fill='x')
        ttk.Label(header, text='Leaf Climate Proxy', font=('Helvetica', 24, 'bold')).pack(anchor='w')
        ttk.Label(header, text='输入叶相特征，调用项目训练模型重建古气候', foreground='#566').pack(anchor='w', pady=(4,0))
        toolbar = ttk.Frame(self, padding=(24, 0, 24, 12)); toolbar.pack(fill='x')
        ttk.Button(toolbar, text='导入 JSON', command=self.import_json).pack(side='left')
        ttk.Button(toolbar, text='清空', command=self.clear).pack(side='left', padx=8)
        ttk.Button(toolbar, text='选择模型目录', command=self.choose_model_dir).pack(side='right', padx=(0, 8))
        ttk.Button(toolbar, text='开始预测', command=self.run_prediction).pack(side='right')
        body = ttk.Panedwindow(self, orient='horizontal'); body.pack(fill='both', expand=True, padx=18, pady=(0,18))
        left = ttk.Frame(body, padding=12); right = ttk.Frame(body, padding=12); body.add(left, weight=3); body.add(right, weight=2)
        ttk.Label(left, text='叶相特征（比例或计数）', font=('Helvetica', 14, 'bold')).pack(anchor='w')
        ttk.Label(left, text='请按训练数据的定义输入 31 个字段；未观察到的特征填 0。', foreground='#566').pack(anchor='w', pady=(2, 10))
        canvas = tk.Canvas(left, highlightthickness=0); scroll = ttk.Scrollbar(left, orient='vertical', command=canvas.yview)
        form = ttk.Frame(canvas); form.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0), window=form, anchor='nw'); canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side='left', fill='both', expand=True); scroll.pack(side='right', fill='y')
        for i, name in enumerate(FEATURES):
            row, col = divmod(i, 2); cell = ttk.Frame(form, padding=(0, 3)); cell.grid(row=row, column=col, sticky='ew', padx=(0, 20 if col == 0 else 0)); form.columnconfigure(col, weight=1)
            ttk.Label(cell, text=name, width=17).pack(side='left'); ttk.Entry(cell, textvariable=self.vars[name], width=10).pack(side='right')
        ttk.Label(right, text='预测气候变量', font=('Helvetica', 14, 'bold')).pack(anchor='w')
        ttk.Label(right, text='温度变量 → 湿度/能量变量（两阶段模型）', foreground='#566').pack(anchor='w', pady=(2, 14))
        self.cards = {}
        for target in TEMP_TARGETS + MOIST_TARGETS:
            card = ttk.Frame(right, padding=12, relief='groove'); card.pack(fill='x', pady=5); self.cards[target] = card
            ttk.Label(card, text=target, font=('Helvetica', 12, 'bold'), width=10).pack(side='left')
            self.model_vars[target].set('加载中…')
            ttk.OptionMenu(card, self.model_vars[target], '加载中…').pack(side='left', padx=4, fill='x', expand=True)
            ttk.Label(card, textvariable=self.result_vars[target], font=('Helvetica', 18, 'bold')).pack(side='right')
        self.status = tk.StringVar(value='正在加载模型…'); ttk.Label(right, textvariable=self.status, wraplength=300, foreground='#566').pack(anchor='w', pady=(18, 0))
        ttk.Label(right, text='模型目录', foreground='#899').pack(anchor='w', pady=(24,0)); self.path_label = ttk.Label(right, text='—', wraplength=300); self.path_label.pack(anchor='w')

    def _load(self):
        try:
            self.models, self.model_dirs = load_models()
            for target, choices in self.models.items():
                menu = self.cards[target].winfo_children()[1]['menu']
                menu.delete(0, 'end')
                names = sorted(choices)
                self.model_vars[target].set(names[0])
                for name in names: menu.add_command(label=name, command=lambda n=name, t=target: self.model_vars[t].set(n))
            self.path_label.config(text='\n'.join(str(p) for p in self.model_dirs)); self.status.set('已加载全部可用模型，可逐项选择。')
        except Exception as exc: self.status.set('模型加载失败：' + str(exc)); messagebox.showerror('模型加载失败', str(exc))

    def choose_model_dir(self):
        directory = filedialog.askdirectory(title='选择包含 .joblib 模型文件的文件夹')
        if not directory:
            return
        try:
            self.models, self.model_dirs = load_models(Path(directory))
            for target, choices in self.models.items():
                menu = self.cards[target].winfo_children()[1]['menu']
                menu.delete(0, 'end')
                names = sorted(choices)
                self.model_vars[target].set(names[0])
                for name in names:
                    menu.add_command(label=name, command=lambda n=name, t=target: self.model_vars[t].set(n))
            self.path_label.config(text='\n'.join(str(p) for p in self.model_dirs))
            self.status.set('已从所选目录加载模型。')
        except Exception as exc:
            self.status.set('模型加载失败：' + str(exc))
            messagebox.showerror('模型加载失败', str(exc))

    def clear(self):
        for v in self.vars.values(): v.set('0')
        for v in self.result_vars.values(): v.set('—')
        self.status.set('已清空输入。')

    def import_json(self):
        path = filedialog.askopenfilename(filetypes=[('JSON', '*.json')])
        if not path: return
        try:
            data = json.loads(Path(path).read_text(encoding='utf-8'))
            for name in FEATURES:
                if name in data: self.vars[name].set(str(data[name]))
            self.status.set(f'已导入 {Path(path).name}。')
        except Exception as exc: messagebox.showerror('导入失败', str(exc))

    def run_prediction(self):
        if not self.models: messagebox.showwarning('模型未就绪', '模型还没有加载完成。'); return
        try:
            values = {k: float(v.get().strip()) for k,v in self.vars.items()}
            selections = {t: self.model_vars[t].get() for t in self.models}
            result = predict(self.models, values, selections)
            for target, value in result.items(): self.result_vars[target].set(f'{value:.2f} {UNITS[target]}')
            self.status.set('预测完成。结果应结合空间验证与化石样品背景解释。')
        except ValueError: messagebox.showerror('输入错误', '所有特征都必须是数字。')
        except Exception as exc: messagebox.showerror('预测失败', str(exc))

if __name__ == '__main__':
    App().mainloop()
